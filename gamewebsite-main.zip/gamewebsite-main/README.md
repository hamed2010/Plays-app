# Gamewebsite
This is gaming website template and fully responsive ( HTML , CSS And JavaScript)

#### Demo Live Now : [GO](https://sm8uti.github.io/gamewebsite/)

## Pc Version

<br/>
<img src="game.png">

##Mobile Version

<img src="game-mobile.png">
